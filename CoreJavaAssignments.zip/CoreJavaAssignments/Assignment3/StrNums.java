package com.broadridge.assignment3;

public class StrNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String input = "DevLabsAllianceTraining�";
		  char search1 = 'D';             // Character to search is 'D'.
		  
		  int count1=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search1)
		      count1++;
		  }
		  
		  System.out.println("The Character '"+search1+"' appears "+count1+" times.");
		  
		  char search2 = 'e';             // Character to search is 'e'.
		  
		  int count2=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search2)
		      count2++;
		  }
		  
		  System.out.println("The Character '"+search2+"' appears "+count2+" times.");

		  char search3 = 'v';             // Character to search is 'v'.
		  
		  int count3=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search3)
		      count3++;
		  }
		  
		  System.out.println("The Character '"+search3+"' appears "+count3+" times.");

		  char search4 = 'l';             // Character to search is 'l'.
		  
		  int count4=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search4)
		      count4++;
		  }
		  
		  System.out.println("The Character '"+search4+"' appears "+count4+" times.");

		  char search5 = 'a';             // Character to search is 'a'.
		  
		  int count5=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search5)
		      count5++;
		  }
		  
		  System.out.println("The Character '"+search5+"' appears "+count5+" times.");

		  char search6 = 'b';             // Character to search is 'b'.
		  
		  int count6=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search6)
		      count6++;
		  }
		  
		  System.out.println("The Character '"+search6+"' appears "+count6+" times.");

		  char search7 = 's';             // Character to search is 's'.
		  
		  int count7=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search7)
		      count7++;
		  }
		  
		  System.out.println("The Character '"+search7+"' appears "+count7+" times.");

	  char search8 = 'i';             // Character to search is 'i'.
		  
		  int count8=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search8)
		      count8++;
		  }
		  
		  System.out.println("The Character '"+search8+"' appears "+count8+" times.");

	  char search9 = 'n';             // Character to search is 'n'.
		  
		  int count9=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search9)
		      count9++;
		  }
		  
		  System.out.println("The Character '"+search9+"' appears "+count9+" times.");
	  char search10 = 'c';             // Character to search is 'c'.
		  
		  int count10=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search10)
		      count10++;
		  }
		  
		  System.out.println("The Character '"+search10+"' appears "+count10+" times.");

	  char search11 = 't';             // Character to search is 't'.
		  
		  int count11=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search11)
		      count11++;
		  }
		  
		  System.out.println("The Character '"+search11+"' appears "+count11+" times.");
	  char search12 = 'r';             // Character to search is 'r'.
		  
		  int count12=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search12)
		      count12++;
		  }
		  
		  System.out.println("The Character '"+search12+"' appears "+count12+" times.");
	  char search13 = 'g';             // Character to search is 'g'.
		  
		  int count13=0;
		  for(int i=0; i<input.length(); i++)
		  {
		      if(input.charAt(i) == search13)
		      count13++;
		  }
		  
		  System.out.println("The Character '"+search13+"' appears "+count13+" times.");

	  }

	}


