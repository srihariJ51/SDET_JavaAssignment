package com.broadridge.assignment;

public class EvenNums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int number=50;  
		System.out.print("List of even numbers from 1 to "+number+": ");  
		for (int i=1; i<=number; i++)   
		{    
		if (i%2==0)   
		{  
		System.out.print(i + " ");  
		}  

	}
		
	}
}


